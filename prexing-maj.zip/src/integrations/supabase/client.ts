import { createClient } from "@supabase/supabase-js";

/**
 * Client Supabase unique de l'application.
 * Les valeurs viennent des variables d'environnement Vite (créées par Lovable quand le
 * projet Supabase est connecté). La clé « anon / publishable » est publique par nature :
 * la sécurité repose sur les règles RLS de la base.
 */
const env = import.meta.env as Record<string, string | undefined>;

export const SUPABASE_URL = env["VITE_SUPABASE_URL"] ?? "";
export const SUPABASE_KEY =
  env["VITE_SUPABASE_PUBLISHABLE_KEY"] ?? env["VITE_SUPABASE_ANON_KEY"] ?? "";

export const supabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_KEY);

export const supabase = createClient(
  SUPABASE_URL || "https://configuration-manquante.supabase.co",
  SUPABASE_KEY || "cle-manquante",
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  },
);
