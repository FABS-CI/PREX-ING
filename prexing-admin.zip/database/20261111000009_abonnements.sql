-- =====================================================================
-- PREX'ING — Migration 9 : abonnements PREX'ING, lecture seule, administration
-- À appliquer après la migration 8. Idempotente.
-- Cycle : essai (14 j) → actif jusqu'à l'échéance → grâce (7 j) → lecture seule.
-- Les données ne sont JAMAIS supprimées : en lecture seule, on consulte, on n'écrit plus.
-- =====================================================================

-- 1. Factures d'abonnement (écrites uniquement par l'équipe PREX'ING)
create table if not exists public.factures_abonnement (
  id uuid primary key default gen_random_uuid(),
  pressing_id uuid not null references public.pressings (id) on delete cascade,
  formule text not null,
  periode_debut date not null,
  periode_fin date not null,
  mois int not null check (mois between 1 and 24),
  montant int not null check (montant >= 0),
  moyen public.moyen_paiement not null default 'wave',
  reference text,
  statut text not null default 'payee' check (statut in ('payee', 'annulee')),
  par uuid references public.profiles (id) default auth.uid(),
  created_at timestamptz not null default now()
);
alter table public.factures_abonnement enable row level security;
drop policy if exists factures_abonnement_select on public.factures_abonnement;
create policy factures_abonnement_select on public.factures_abonnement for select to authenticated
  using (public.has_role(pressing_id, '{proprietaire}') or public.is_super_admin());
drop policy if exists factures_abonnement_admin on public.factures_abonnement;
create policy factures_abonnement_admin on public.factures_abonnement for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

-- 2. Statut réel calculé à partir des dates (pas besoin de tâche planifiée)
create or replace function public.statut_effectif(p_pressing uuid)
returns public.statut_abonnement_saas language sql stable security definer set search_path = public as $$
  select case
    when p.statut_abonnement = 'suspendu' then 'suspendu'
    when p.echeance is null and current_date <= p.essai_fin then 'essai'
    when p.echeance is null and current_date <= p.essai_fin + 7 then 'grace'
    when p.echeance is null then 'lecture_seule'
    when current_date <= p.echeance then 'actif'
    when current_date <= p.echeance + 7 then 'grace'
    else 'lecture_seule' end::public.statut_abonnement_saas
  from public.pressings p where p.id = p_pressing;
$$;

create or replace function public.mon_abonnement(p_pressing uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'statut', public.statut_effectif(p.id), 'formule', p.formule, 'essai_fin', p.essai_fin, 'echeance', p.echeance,
    'fin', coalesce(p.echeance, p.essai_fin),
    'nb_boutiques', (select count(*) from public.boutiques b where b.pressing_id = p.id and b.actif and b.deleted_at is null),
    'factures', coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'formule', f.formule, 'periode_debut', f.periode_debut,
                 'periode_fin', f.periode_fin, 'montant', f.montant, 'moyen', f.moyen, 'created_at', f.created_at) order by f.created_at desc)
               from public.factures_abonnement f where f.pressing_id = p.id and f.statut = 'payee'), '[]'))
  from public.pressings p
  where p.id = p_pressing and (public.is_member(p.id) or public.is_super_admin());
$$;

-- 3. Lecture seule : toute écriture est refusée (sauf pour l'équipe PREX'ING)
create or replace function public.verifier_ecriture()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_pressing uuid := coalesce(case when tg_op = 'DELETE' then old.pressing_id else new.pressing_id end, old.pressing_id);
  v_statut public.statut_abonnement_saas;
begin
  if v_pressing is not null and not public.is_super_admin() then
    v_statut := public.statut_effectif(v_pressing);
    if v_statut in ('lecture_seule', 'suspendu') then
      raise exception 'Abonnement PREX''ING expiré : le compte est en lecture seule. Vos données sont conservées ; renouvelez l''abonnement pour continuer.'
        using errcode = '42501';
    end if;
  end if;
  return case when tg_op = 'DELETE' then old else new end;
end $$;

do $$
declare t text;
begin
  for t in
    select c.table_name from information_schema.columns c
    join information_schema.tables tb on tb.table_schema = c.table_schema and tb.table_name = c.table_name and tb.table_type = 'BASE TABLE'
    where c.table_schema = 'public' and c.column_name = 'pressing_id'
      and c.table_name not in ('factures_abonnement', 'journal_audit', 'audit_log', 'depot_historique')
  loop
    execute format('drop trigger if exists trg_verifier_ecriture on public.%I', t);
    execute format('create trigger trg_verifier_ecriture before insert or update or delete on public.%I
                    for each row execute function public.verifier_ecriture()', t);
  end loop;
end $$;

-- 4. Le propriétaire ne peut pas modifier lui-même son abonnement
create or replace function public.proteger_abonnement()
returns trigger language plpgsql security invoker set search_path = public as $$
begin
  if not public.is_super_admin() and (
       new.formule is distinct from old.formule or new.statut_abonnement is distinct from old.statut_abonnement
    or new.essai_fin is distinct from old.essai_fin or new.echeance is distinct from old.echeance) then
    raise exception 'L''abonnement est géré par l''équipe PREX''ING.' using errcode = '42501';
  end if;
  if public.statut_effectif(new.id) in ('lecture_seule', 'suspendu') and not public.is_super_admin() then
    raise exception 'Abonnement PREX''ING expiré : le compte est en lecture seule.' using errcode = '42501';
  end if;
  return new;
end $$;

drop trigger if exists trg_proteger_abonnement on public.pressings;
create trigger trg_proteger_abonnement before update on public.pressings
  for each row execute function public.proteger_abonnement();

-- 5. Administration PREX'ING (super-administrateurs uniquement)
create or replace function public.admin_pressings()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_super_admin() then
    raise exception 'Réservé à l''équipe PREX''ING.' using errcode = '42501';
  end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', p.id, 'nom', p.nom, 'telephone', p.telephone, 'ville', p.ville, 'slug', p.slug,
      'formule', p.formule, 'statut', public.statut_effectif(p.id), 'essai_fin', p.essai_fin, 'echeance', p.echeance,
      'created_at', p.created_at,
      'proprietaire', (select jsonb_build_object('nom', pr.nom, 'telephone', pr.telephone)
                         from public.memberships m join public.profiles pr on pr.id = m.user_id
                        where m.pressing_id = p.id and m.role = 'proprietaire' limit 1),
      'nb_boutiques', (select count(*) from public.boutiques b where b.pressing_id = p.id and b.deleted_at is null),
      'nb_utilisateurs', (select count(*) from public.memberships m where m.pressing_id = p.id and m.actif),
      'depots_30j', (select count(*) from public.depots d where d.pressing_id = p.id and d.deleted_at is null
                      and d.created_at >= now() - interval '30 days'),
      'derniere_activite', (select max(d.created_at) from public.depots d where d.pressing_id = p.id),
      'total_paye', (select coalesce(sum(f.montant), 0) from public.factures_abonnement f where f.pressing_id = p.id and f.statut = 'payee'))
      order by p.created_at desc)
    from public.pressings p where p.deleted_at is null), '[]');
end $$;

create or replace function public.admin_enregistrer_paiement(
  p_pressing uuid, p_formule text, p_mois int, p_montant int, p_moyen public.moyen_paiement, p_reference text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_debut date;
  v_fin date;
begin
  if not public.is_super_admin() then
    raise exception 'Réservé à l''équipe PREX''ING.' using errcode = '42501';
  end if;
  if p_formule not in ('essentiel', 'pro', 'multi') then
    raise exception 'Formule inconnue.' using errcode = '22023';
  end if;
  if p_mois is null or p_mois < 1 or p_mois > 24 then
    raise exception 'Durée invalide (1 à 24 mois).' using errcode = '22023';
  end if;
  select greatest(coalesce(echeance, current_date - 1), current_date - 1) + 1 into v_debut
    from public.pressings where id = p_pressing;
  if v_debut is null then
    raise exception 'Pressing introuvable.' using errcode = 'P0002';
  end if;
  v_fin := (v_debut + make_interval(months => p_mois))::date - 1;
  insert into public.factures_abonnement (pressing_id, formule, periode_debut, periode_fin, mois, montant, moyen, reference)
  values (p_pressing, p_formule, v_debut, v_fin, p_mois, p_montant, p_moyen, nullif(trim(p_reference), ''));
  update public.pressings set formule = p_formule, echeance = v_fin, statut_abonnement = 'actif' where id = p_pressing;
  return jsonb_build_object('debut', v_debut, 'fin', v_fin);
end $$;

create or replace function public.admin_suspendre(p_pressing uuid, p_suspendre boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_super_admin() then
    raise exception 'Réservé à l''équipe PREX''ING.' using errcode = '42501';
  end if;
  update public.pressings
     set statut_abonnement = case when p_suspendre then 'suspendu'
                                  when echeance is null then 'essai' else 'actif' end::public.statut_abonnement_saas
   where id = p_pressing;
end $$;

grant execute on function public.statut_effectif(uuid) to authenticated;
grant execute on function public.mon_abonnement(uuid) to authenticated;
grant execute on function public.admin_pressings() to authenticated;
grant execute on function public.admin_enregistrer_paiement(uuid, text, int, int, public.moyen_paiement, text) to authenticated;
grant execute on function public.admin_suspendre(uuid, boolean) to authenticated;
grant select, insert, update, delete on public.factures_abonnement to authenticated;
