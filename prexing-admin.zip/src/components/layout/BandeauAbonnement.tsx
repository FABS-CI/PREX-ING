import { Link } from "@tanstack/react-router";
import { Lock, TriangleAlert } from "lucide-react";

import { useSession } from "@/contexts/SessionContext";
import { useMonAbonnement } from "@/hooks/useAbonnement";
import { JOURS_GRACE, joursRestants, WHATSAPP_PREXING } from "@/lib/abonnement";
import { formatDate, lienWhatsApp } from "@/lib/format";
import { cn } from "@/lib/utils";

/** Alerte d'abonnement en haut de l'application : fin d'essai proche, grâce, lecture seule. */
export function BandeauAbonnement() {
  const { pressing, role } = useSession();
  const { data: a } = useMonAbonnement(pressing?.id);
  if (!a || !pressing) return null;
  const restants = joursRestants(a.fin) ?? 0;
  const proprio = role === "proprietaire";
  let texte: string | null = null;
  let grave = false;
  if (a.statut === "essai" && restants <= 5)
    texte = `Votre essai gratuit se termine ${restants <= 0 ? "aujourd’hui" : `dans ${restants} jour${restants > 1 ? "s" : ""}`} (${formatDate(a.fin)}).`;
  if (a.statut === "actif" && restants <= 5)
    texte = `Votre abonnement arrive à échéance le ${formatDate(a.fin)}.`;
  if (a.statut === "grace") {
    const reste = JOURS_GRACE + restants;
    texte = `Abonnement échu le ${formatDate(a.fin)}. Il reste ${reste} jour${reste > 1 ? "s" : ""} avant le passage en lecture seule.`;
  }
  if (a.statut === "lecture_seule" || a.statut === "suspendu") {
    grave = true;
    texte =
      a.statut === "suspendu"
        ? "Compte suspendu : consultation seule."
        : "Abonnement expiré : le compte est en lecture seule. Vos données sont conservées.";
  }
  if (!texte) return null;
  const Icone = grave ? Lock : TriangleAlert;
  return (
    <div
      className={cn(
        "mb-4 flex flex-wrap items-center gap-3 rounded-xl border px-4 py-3 text-sm",
        grave ? "border-destructive/40 bg-destructive/10" : "border-warning/40 bg-warning/10",
      )}
    >
      <Icone className={cn("size-4 shrink-0", grave ? "text-destructive" : "text-warning")} />
      <span className="min-w-0 flex-1">
        {texte}
        {!proprio ? " Prévenez le propriétaire." : ""}
      </span>
      {proprio ? (
        <span className="flex gap-3">
          <Link to="/parametres" className="font-medium underline">
            Voir l’abonnement
          </Link>
          <a
            href={lienWhatsApp(
              WHATSAPP_PREXING,
              `Bonjour, je souhaite renouveler l’abonnement PREX’ING de ${pressing.nom}.`,
            )}
            target="_blank"
            rel="noreferrer"
            className="font-medium underline"
          >
            Renouveler
          </a>
        </span>
      ) : null}
    </div>
  );
}
