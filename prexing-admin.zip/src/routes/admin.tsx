import { useMemo, useState } from "react";
import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { Ban, LogOut, MessageCircle, Search, Wallet } from "lucide-react";
import { toast } from "sonner";

import { Champ } from "@/components/common/Champ";
import { Chargement } from "@/components/common/Chargement";
import { Logo } from "@/components/common/Logo";
import { SaisieMontant } from "@/components/common/SaisieMontant";
import { MOYENS_COMPTOIR } from "@/components/comptoir/Panier";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useSession } from "@/contexts/SessionContext";
import {
  useAdminPaiement,
  useAdminPressings,
  useAdminSuspendre,
  type PressingAdmin,
} from "@/hooks/useAbonnement";
import {
  FORMULES,
  LIBELLES_STATUT_ABONNEMENT,
  montantPeriode,
  prixMensuel,
  type CodeFormule,
  type StatutAbonnement,
} from "@/lib/abonnement";
import { messageErreur } from "@/lib/erreurs";
import { formatDate, formatFCFA, formatTelephone, lienWhatsApp } from "@/lib/format";
import { LIBELLES_MOYEN, type MoyenPaiement } from "@/lib/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [{ title: "Administration — PREX’ING" }, { name: "robots", content: "noindex" }],
  }),
  component: AdminPage,
});

const COULEURS: Record<StatutAbonnement, string> = {
  essai: "bg-info/15 text-info",
  actif: "bg-success/15 text-success",
  grace: "bg-warning/15 text-warning",
  lecture_seule: "bg-destructive/10 text-destructive",
  suspendu: "bg-muted text-muted-foreground",
};

function DialoguePaiement({ p, onFermer }: { p: PressingAdmin; onFermer: () => void }) {
  const payer = useAdminPaiement();
  const [formule, setFormule] = useState<CodeFormule>(
    p.formule in FORMULES ? (p.formule as CodeFormule) : "pro",
  );
  const [mois, setMois] = useState(1);
  const [montant, setMontant] = useState<number | null>(null);
  const [moyen, setMoyen] = useState<MoyenPaiement>("wave");
  const [reference, setReference] = useState("");
  const suggere = montantPeriode(formule, p.nb_boutiques, mois);
  const m = montant ?? suggere;
  return (
    <Dialog open onOpenChange={(o) => !o && onFermer()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Paiement reçu — {p.nom}</DialogTitle>
          <DialogDescription>
            {p.echeance
              ? `Payé jusqu’au ${formatDate(p.echeance)} ; la nouvelle période commence ensuite.`
              : "Première période à partir d’aujourd’hui."}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-2">
            {(Object.keys(FORMULES) as CodeFormule[]).map((k) => (
              <button
                key={k}
                type="button"
                onClick={() => {
                  setFormule(k);
                  setMontant(null);
                }}
                className={cn(
                  "rounded-xl border p-2 text-left text-sm",
                  formule === k ? "border-primary ring-1 ring-primary" : "",
                )}
              >
                <span className="block font-semibold">{FORMULES[k].nom}</span>
                <span className="montant block text-xs text-muted-foreground">
                  {formatFCFA(prixMensuel(k, p.nb_boutiques))}/mois
                </span>
              </button>
            ))}
          </div>
          <div className="flex flex-wrap gap-1.5">
            {[1, 3, 6, 12].map((n) => (
              <button
                key={n}
                type="button"
                onClick={() => {
                  setMois(n);
                  setMontant(null);
                }}
                className={cn(
                  "h-9 rounded-lg border px-3 text-sm font-medium",
                  mois === n ? "border-primary bg-primary text-primary-foreground" : "bg-card",
                )}
              >
                {n} mois{n === 12 ? " (2 offerts)" : ""}
              </button>
            ))}
          </div>
          <Champ id="ad-m" libelle="Montant reçu" aide={`Tarif : ${formatFCFA(suggere)}`}>
            <SaisieMontant id="ad-m" valeur={m} onChange={setMontant} />
          </Champ>
          <div className="flex flex-wrap gap-1.5">
            {MOYENS_COMPTOIR.map((x) => (
              <button
                key={x}
                type="button"
                onClick={() => setMoyen(x)}
                className={cn(
                  "h-9 rounded-lg border px-3 text-sm font-medium",
                  moyen === x ? "border-primary bg-primary text-primary-foreground" : "bg-card",
                )}
              >
                {LIBELLES_MOYEN[x]}
              </button>
            ))}
          </div>
          <Champ id="ad-ref" libelle="Référence de transaction">
            <Input
              id="ad-ref"
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              className="h-11"
            />
          </Champ>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onFermer}>
            Annuler
          </Button>
          <Button
            disabled={payer.isPending || (moyen !== "especes" && !reference.trim())}
            onClick={() =>
              payer
                .mutateAsync({ pressingId: p.id, formule, mois, montant: m, moyen, reference })
                .then((r) => {
                  toast.success(`Abonnement actif jusqu’au ${formatDate(r.fin)}.`);
                  onFermer();
                })
                .catch((e: unknown) => toast.error(messageErreur(e)))
            }
          >
            Enregistrer le paiement
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function AdminPage() {
  const { etat, profil, deconnexion } = useSession();
  const estAdmin = Boolean(profil?.is_super_admin);
  const { data, isLoading, error } = useAdminPressings(estAdmin);
  const suspendre = useAdminSuspendre();
  const [recherche, setRecherche] = useState("");
  const [filtre, setFiltre] = useState<StatutAbonnement | "tous">("tous");
  const [paiement, setPaiement] = useState<PressingAdmin | null>(null);

  const stats = useMemo(() => {
    const l = data ?? [];
    const par = (s: StatutAbonnement) => l.filter((p) => p.statut === s).length;
    const mrr = l
      .filter((p) => p.statut === "actif" || p.statut === "grace")
      .reduce(
        (a, p) =>
          a + (p.formule in FORMULES ? prixMensuel(p.formule as CodeFormule, p.nb_boutiques) : 0),
        0,
      );
    return {
      total: l.length,
      essai: par("essai"),
      actif: par("actif"),
      grace: par("grace"),
      bloques: par("lecture_seule") + par("suspendu"),
      mrr,
      depots: l.reduce((a, p) => a + p.depots_30j, 0),
      encaisse: l.reduce((a, p) => a + p.total_paye, 0),
    };
  }, [data]);

  if (etat === "chargement") return <Chargement plein />;
  if (etat === "deconnecte") return <Navigate to="/connexion" replace />;
  if (!estAdmin) return <Navigate to="/" replace />;

  const t = recherche.trim().toLowerCase();
  const liste = (data ?? []).filter(
    (p) =>
      (filtre === "tous" || p.statut === filtre) &&
      (!t ||
        `${p.nom} ${p.proprietaire?.nom ?? ""} ${p.telephone ?? ""} ${p.ville ?? ""}`
          .toLowerCase()
          .includes(t)),
  );

  return (
    <div className="min-h-screen bg-background">
      <header className="flex h-14 items-center gap-3 border-b bg-sidebar px-4 text-sidebar-foreground md:px-6">
        <Logo clair />
        <span className="text-sm text-sidebar-foreground/70">Administration</span>
        <div className="ml-auto flex items-center gap-2">
          <Button
            asChild
            size="sm"
            variant="ghost"
            className="text-sidebar-foreground hover:bg-sidebar-accent hover:text-white"
          >
            <Link to="/">Application</Link>
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="text-sidebar-foreground hover:bg-sidebar-accent hover:text-white"
            onClick={() => void deconnexion()}
          >
            <LogOut />
            Quitter
          </Button>
        </div>
      </header>
      <main className="mx-auto max-w-7xl space-y-6 px-4 py-6 md:px-6">
        <section className="grid grid-cols-2 divide-x divide-y overflow-hidden rounded-2xl border bg-card lg:grid-cols-4 lg:divide-y-0">
          {[
            ["Pressings", String(stats.total), `${stats.essai} en essai · ${stats.actif} actifs`],
            ["Revenu mensuel", formatFCFA(stats.mrr), "abonnements actifs et en grâce"],
            ["À relancer", String(stats.grace), `${stats.bloques} en lecture seule ou suspendus`],
            [
              "Activité (30 j)",
              `${stats.depots} dépôts`,
              `${formatFCFA(stats.encaisse)} encaissés au total`,
            ],
          ].map(([l, v, d]) => (
            <div key={l} className="px-5 py-4">
              <p className="text-xs text-muted-foreground">{l}</p>
              <p className="montant mt-1 text-2xl font-bold">{v}</p>
              <p className="mt-0.5 text-xs text-muted-foreground">{d}</p>
            </div>
          ))}
        </section>

        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <div className="relative w-full sm:max-w-sm">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={recherche}
              onChange={(e) => setRecherche(e.target.value)}
              placeholder="Pressing, propriétaire, téléphone, ville"
              className="h-10 pl-9"
              aria-label="Rechercher un pressing"
            />
          </div>
          <div className="flex flex-wrap gap-1.5">
            {(["tous", "essai", "actif", "grace", "lecture_seule", "suspendu"] as const).map(
              (s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setFiltre(s)}
                  className={cn(
                    "h-9 rounded-full px-3 text-sm font-medium",
                    filtre === s
                      ? "bg-foreground text-background"
                      : "bg-muted text-muted-foreground",
                  )}
                >
                  {s === "tous" ? "Tous" : LIBELLES_STATUT_ABONNEMENT[s]}
                </button>
              ),
            )}
          </div>
        </div>

        {isLoading ? <Chargement /> : null}
        {error ? (
          <p className="rounded-lg bg-destructive/10 p-4 text-sm text-destructive">
            {messageErreur(error)}
          </p>
        ) : null}
        <ul className="space-y-2">
          {liste.map((p) => (
            <li
              key={p.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-card p-4"
            >
              <div className="min-w-0">
                <p className="flex flex-wrap items-center gap-2 font-semibold">
                  {p.nom}
                  <span
                    className={cn(
                      "rounded-full px-2 py-0.5 text-xs font-semibold",
                      COULEURS[p.statut],
                    )}
                  >
                    {LIBELLES_STATUT_ABONNEMENT[p.statut]}
                  </span>
                  <span className="text-xs font-normal text-muted-foreground">
                    {p.formule in FORMULES ? FORMULES[p.formule as CodeFormule].nom : "Essai"}
                  </span>
                </p>
                <p className="text-xs text-muted-foreground">
                  {p.proprietaire?.nom ?? "—"}
                  {p.proprietaire?.telephone
                    ? ` · ${formatTelephone(p.proprietaire.telephone)}`
                    : ""}
                  {p.ville ? ` · ${p.ville}` : ""}
                  {` · ${p.nb_boutiques} boutique${p.nb_boutiques > 1 ? "s" : ""} · ${p.nb_utilisateurs} utilisateur${p.nb_utilisateurs > 1 ? "s" : ""}`}
                </p>
                <p className="text-xs text-muted-foreground">
                  {p.echeance
                    ? `Payé jusqu’au ${formatDate(p.echeance)}`
                    : `Essai jusqu’au ${formatDate(p.essai_fin)}`}{" "}
                  · {p.depots_30j} dépôts sur 30 j
                  {p.derniere_activite
                    ? ` · dernier le ${formatDate(p.derniere_activite)}`
                    : " · aucune activité"}{" "}
                  · inscrit le {formatDate(p.created_at)}
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                {p.proprietaire?.telephone ? (
                  <Button asChild size="sm" variant="outline">
                    <a
                      href={lienWhatsApp(
                        p.proprietaire.telephone,
                        `Bonjour ${p.proprietaire.nom ?? ""}, ici l’équipe PREX’ING.`,
                      )}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <MessageCircle />
                      WhatsApp
                    </a>
                  </Button>
                ) : null}
                <Button size="sm" onClick={() => setPaiement(p)}>
                  <Wallet />
                  Paiement
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className={p.statut === "suspendu" ? "" : "text-destructive"}
                  disabled={suspendre.isPending}
                  onClick={() =>
                    suspendre
                      .mutateAsync({ pressingId: p.id, suspendre: p.statut !== "suspendu" })
                      .then(() =>
                        toast.success(
                          p.statut === "suspendu"
                            ? "Compte réactivé."
                            : "Compte suspendu (lecture seule).",
                        ),
                      )
                      .catch((e: unknown) => toast.error(messageErreur(e)))
                  }
                >
                  <Ban />
                  {p.statut === "suspendu" ? "Réactiver" : "Suspendre"}
                </Button>
              </div>
            </li>
          ))}
        </ul>
      </main>
      {paiement ? <DialoguePaiement p={paiement} onFermer={() => setPaiement(null)} /> : null}
    </div>
  );
}
