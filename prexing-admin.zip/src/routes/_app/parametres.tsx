import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Copy, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Champ } from "@/components/common/Champ";
import { PageHeader } from "@/components/common/PageHeader";
import { QrCode } from "@/components/common/QrCode";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useEspace } from "@/contexts/SessionContext";
import {
  lienPagePressing,
  useModifierBoutique,
  useModifierSlug,
  useSlugPressing,
} from "@/hooks/usePortail";
import { messageErreur } from "@/lib/erreurs";
import { useMonAbonnement } from "@/hooks/useAbonnement";
import {
  FORMULES,
  LIBELLES_STATUT_ABONNEMENT,
  prixMensuel,
  WHATSAPP_PREXING,
  type CodeFormule,
} from "@/lib/abonnement";
import { formatDate, formatFCFA, lienWhatsApp } from "@/lib/format";
import { codeAppareil, definirCodeAppareil } from "@/lib/numerotation";
import { LIBELLES_MOYEN } from "@/lib/types";

export const Route = createFileRoute("/_app/parametres")({
  head: () => ({ meta: [{ title: "Paramètres — PREX’ING" }] }),
  component: ParametresPage,
});

function Section({
  titre,
  description,
  children,
}: {
  titre: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border bg-card p-5">
      <h2 className="font-semibold">{titre}</h2>
      {description ? <p className="mt-0.5 text-sm text-muted-foreground">{description}</p> : null}
      <div className="mt-4">{children}</div>
    </section>
  );
}

function Boutique() {
  const { boutique, recharger } = useEspace();
  const modifier = useModifierBoutique();
  const [v, setV] = useState({
    nom: boutique.nom,
    adresse: boutique.adresse ?? "",
    commune: boutique.commune ?? "",
    telephone: boutique.telephone ?? "",
    pied_ticket: boutique.pied_ticket ?? "",
  });
  const maj = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setV((x) => ({ ...x, [k]: e.target.value }));
  return (
    <Section
      titre="Boutique"
      description="Ces informations apparaissent sur les tickets et sur votre page publique."
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <Champ id="b-nom" libelle="Nom">
          <Input id="b-nom" value={v.nom} onChange={maj("nom")} className="h-11" />
        </Champ>
        <Champ id="b-tel" libelle="Téléphone">
          <Input
            id="b-tel"
            type="tel"
            value={v.telephone}
            onChange={maj("telephone")}
            className="h-11"
          />
        </Champ>
        <Champ id="b-adr" libelle="Adresse">
          <Input id="b-adr" value={v.adresse} onChange={maj("adresse")} className="h-11" />
        </Champ>
        <Champ id="b-com" libelle="Commune">
          <Input id="b-com" value={v.commune} onChange={maj("commune")} className="h-11" />
        </Champ>
      </div>
      <div className="mt-3">
        <Champ id="b-pied" libelle="Message en bas du ticket">
          <Input id="b-pied" value={v.pied_ticket} onChange={maj("pied_ticket")} className="h-11" />
        </Champ>
      </div>
      <Button
        className="mt-4"
        disabled={v.nom.trim().length < 2 || modifier.isPending}
        onClick={() =>
          modifier
            .mutateAsync({ id: boutique.id, ...v })
            .then(() => {
              toast.success("Boutique enregistrée.");
              return recharger();
            })
            .catch((e: unknown) => toast.error(messageErreur(e)))
        }
      >
        {modifier.isPending ? <Loader2 className="animate-spin" /> : null}Enregistrer
      </Button>
    </Section>
  );
}

function PageEnLigne() {
  const { pressing } = useEspace();
  const { data: slug } = useSlugPressing(pressing.id);
  const modifier = useModifierSlug(pressing.id);
  const [saisie, setSaisie] = useState<string | null>(null);
  if (!slug) return null;
  const lien = lienPagePressing(slug);
  return (
    <Section
      titre="Page en ligne"
      description="Vos clients y voient vos tarifs et demandent un ramassage, sans rien installer."
    >
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start">
        <div className="rounded-xl border bg-white p-2">
          <QrCode valeur={lien} taille={132} label="QR code de votre page" />
        </div>
        <div className="min-w-0 flex-1 space-y-3">
          <a
            href={lien}
            target="_blank"
            rel="noreferrer"
            className="block truncate font-medium text-primary underline dark:text-info"
          >
            {lien}
          </a>
          <Button
            size="sm"
            variant="outline"
            onClick={() =>
              void navigator.clipboard.writeText(lien).then(() => toast.success("Lien copié."))
            }
          >
            <Copy />
            Copier le lien
          </Button>
          <Champ
            id="slug"
            libelle="Adresse de la page"
            aide="Lettres, chiffres et tirets. Changer l’adresse rend l’ancien lien invalide."
          >
            <div className="flex gap-2">
              <Input
                id="slug"
                value={saisie ?? slug}
                onChange={(e) => setSaisie(e.target.value)}
                className="h-10"
              />
              <Button
                className="h-10"
                disabled={!saisie || saisie === slug || modifier.isPending}
                onClick={() =>
                  modifier
                    .mutateAsync(saisie ?? slug)
                    .then(() => {
                      toast.success("Adresse modifiée.");
                      setSaisie(null);
                    })
                    .catch((e: unknown) => toast.error(messageErreur(e)))
                }
              >
                OK
              </Button>
            </div>
          </Champ>
        </div>
      </div>
    </Section>
  );
}

function Appareil() {
  const [code, setCode] = useState(codeAppareil());
  return (
    <Section
      titre="Cet appareil"
      description="Code utilisé dans les numéros de dépôt créés ici (ex. A-B2-0043). Chaque appareil d’une boutique doit avoir un code différent."
    >
      <div className="flex gap-2">
        <Input
          value={code}
          maxLength={2}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          className="h-10 w-24 text-center font-semibold tracking-widest"
          aria-label="Code de l’appareil"
        />
        <Button
          className="h-10"
          variant="outline"
          onClick={() => {
            try {
              definirCodeAppareil(code);
              toast.success("Code de l’appareil enregistré.");
            } catch (e) {
              toast.error(messageErreur(e));
            }
          }}
        >
          Enregistrer
        </Button>
      </div>
    </Section>
  );
}

function Abonnement() {
  const { pressing, role } = useEspace();
  const { data: a } = useMonAbonnement(pressing.id);
  if (!a || role !== "proprietaire") return null;
  const formule = a.formule in FORMULES ? FORMULES[a.formule as CodeFormule] : null;
  return (
    <Section titre="Abonnement PREX’ING">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <p className="text-lg font-semibold">
          {formule?.nom ?? "Essai gratuit"} · {LIBELLES_STATUT_ABONNEMENT[a.statut]}
        </p>
        <p className="text-sm text-muted-foreground">
          {a.echeance
            ? `Payé jusqu’au ${formatDate(a.echeance)}`
            : `Essai jusqu’au ${formatDate(a.essai_fin)}`}
        </p>
      </div>
      <div className="mt-4 grid gap-2 sm:grid-cols-3">
        {(Object.keys(FORMULES) as CodeFormule[]).map((k) => (
          <div
            key={k}
            className={
              a.formule === k ? "rounded-xl border-2 border-primary p-3" : "rounded-xl border p-3"
            }
          >
            <p className="font-semibold">{FORMULES[k].nom}</p>
            <p className="montant text-lg font-bold">
              {formatFCFA(prixMensuel(k, a.nb_boutiques))}
              <span className="text-xs font-normal text-muted-foreground"> / mois</span>
            </p>
            <p className="mt-1 text-xs text-muted-foreground">{FORMULES[k].contenu}</p>
          </div>
        ))}
      </div>
      <p className="mt-3 text-xs text-muted-foreground">
        Paiement annuel : 2 mois offerts. Payez par Wave, Orange Money ou MTN MoMo, puis envoyez la
        référence à l’équipe PREX’ING.
      </p>
      <Button asChild className="mt-3">
        <a
          href={lienWhatsApp(
            WHATSAPP_PREXING,
            `Bonjour, je souhaite payer l’abonnement PREX’ING de ${pressing.nom}.`,
          )}
          target="_blank"
          rel="noreferrer"
        >
          Payer ou changer de formule
        </a>
      </Button>
      {a.factures.length ? (
        <ul className="mt-4 divide-y rounded-xl border text-sm">
          {a.factures.map((f) => (
            <li key={f.id} className="flex justify-between gap-3 px-3 py-2">
              <span>
                {FORMULES[f.formule]?.nom ?? f.formule} · du {formatDate(f.periode_debut)} au{" "}
                {formatDate(f.periode_fin)}
                <span className="block text-xs text-muted-foreground">
                  {LIBELLES_MOYEN[f.moyen]} · le {formatDate(f.created_at)}
                </span>
              </span>
              <span className="montant font-semibold">{formatFCFA(f.montant)}</span>
            </li>
          ))}
        </ul>
      ) : null}
    </Section>
  );
}

function ParametresPage() {
  return (
    <>
      <PageHeader titre="Paramètres" />
      <div className="space-y-6">
        <Abonnement />
        <Boutique />
        <PageEnLigne />
        <Appareil />
      </div>
    </>
  );
}
