import { QueryClient } from "@tanstack/react-query";
import { createRouter, rootRouteId } from "@tanstack/react-router";
import { describe, expect, it } from "vitest";

import { routeTree } from "@/routeTree.gen";

// Match routes without running loaders or rendering: loaders may need a server or
// network the test run lacks, and jsdom never loads the stylesheets React waits on.
describe("App routing", () => {
  it("matches a page for / instead of falling back to not found", () => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });

    const matches = router.matchRoutes("/");

    expect(matches.at(-1)?.routeId).not.toBe(rootRouteId);
  });
});

describe("Pages PREX'ING", () => {
  const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });
  it.each([
    "/connexion",
    "/inscription",
    "/creer-pressing",
    "/tableau-de-bord",
    "/comptoir",
    "/clients",
    "/clients/abc",
    "/catalogue",
    "/depots",
    "/depots/abc",
    "/caisse",
    "/livraisons",
    "/commandes",
    "/equipe",
    "/parametres",
    "/p/mon-pressing",
    "/suivi/abc",
    "/admin",
  ])("trouve une page pour %s", (chemin) => {
    const matches = router.matchRoutes(chemin);
    expect(matches.at(-1)?.routeId).not.toBe(rootRouteId);
    expect(matches.at(-1)?.routeId).not.toBe("__root__");
  });
});
