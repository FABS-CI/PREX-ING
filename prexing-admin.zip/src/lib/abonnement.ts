/** Formules PREX'ING (prix indicatifs du cahier des charges, à ajuster après les entretiens). */

export type CodeFormule = "essentiel" | "pro" | "multi";
export type StatutAbonnement = "essai" | "actif" | "grace" | "lecture_seule" | "suspendu";

export const FORMULES: Record<
  CodeFormule,
  { nom: string; prix: number; parBoutique: boolean; contenu: string }
> = {
  essentiel: {
    nom: "Essentiel",
    prix: 10000,
    parBoutique: false,
    contenu: "1 boutique, 2 utilisateurs, comptoir, dépôts, caisse, tickets",
  },
  pro: {
    nom: "Pro",
    prix: 20000,
    parBoutique: false,
    contenu: "1 boutique, utilisateurs illimités, tous les modules",
  },
  multi: {
    nom: "Multi-boutiques",
    prix: 15000,
    parBoutique: true,
    contenu: "Tout le Pro, plusieurs boutiques, vue consolidée",
  },
};

export const LIBELLES_STATUT_ABONNEMENT: Record<StatutAbonnement, string> = {
  essai: "Essai gratuit",
  actif: "Actif",
  grace: "Période de grâce",
  lecture_seule: "Lecture seule",
  suspendu: "Suspendu",
};

export const JOURS_GRACE = 7;

/** Numéro WhatsApp de l'équipe PREX'ING pour le renouvellement. À remplacer par le vrai numéro. */
export const WHATSAPP_PREXING = "0700000000";

/** Prix mensuel d'une formule (la formule Multi est facturée par boutique). */
export function prixMensuel(formule: CodeFormule, nbBoutiques: number): number {
  const f = FORMULES[formule];
  return f.parBoutique ? f.prix * Math.max(1, nbBoutiques) : f.prix;
}

/** Remise annuelle : 12 mois payés d'un coup = 2 mois offerts. */
export function montantPeriode(formule: CodeFormule, nbBoutiques: number, mois: number): number {
  const mensuel = prixMensuel(formule, nbBoutiques);
  return mois >= 12 ? mensuel * (mois - 2 * Math.floor(mois / 12)) : mensuel * mois;
}

export function joursRestants(fin: string | null, maintenant = new Date()): number | null {
  if (!fin) return null;
  const [a, m, j] = fin.split("-").map(Number);
  const d = new Date(a ?? 2026, (m ?? 1) - 1, j ?? 1);
  const auj = new Date(maintenant.getFullYear(), maintenant.getMonth(), maintenant.getDate());
  return Math.round((d.getTime() - auj.getTime()) / 864e5);
}
