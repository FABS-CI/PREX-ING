import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { rpcLibre } from "@/hooks/useModesAvances";
import type { CodeFormule, StatutAbonnement } from "@/lib/abonnement";
import type { MoyenPaiement } from "@/lib/types";

export interface Facture {
  id: string;
  formule: CodeFormule;
  periode_debut: string;
  periode_fin: string;
  montant: number;
  moyen: MoyenPaiement;
  created_at: string;
}
export interface MonAbonnement {
  statut: StatutAbonnement;
  formule: string;
  essai_fin: string;
  echeance: string | null;
  fin: string;
  nb_boutiques: number;
  factures: Facture[];
}
export interface PressingAdmin {
  id: string;
  nom: string;
  telephone: string | null;
  ville: string | null;
  slug: string | null;
  formule: string;
  statut: StatutAbonnement;
  essai_fin: string;
  echeance: string | null;
  created_at: string;
  proprietaire: { nom: string | null; telephone: string | null } | null;
  nb_boutiques: number;
  nb_utilisateurs: number;
  depots_30j: number;
  derniere_activite: string | null;
  total_paye: number;
}

export function useMonAbonnement(pressingId: string | undefined) {
  return useQuery({
    queryKey: ["abonnement", pressingId],
    enabled: Boolean(pressingId),
    staleTime: 5 * 60_000,
    queryFn: async () => {
      const { data, error } = await rpcLibre("mon_abonnement", { p_pressing: pressingId });
      if (error) throw error;
      return (data ?? null) as MonAbonnement | null;
    },
  });
}

export function useAdminPressings(actif: boolean) {
  return useQuery({
    queryKey: ["admin-pressings"],
    enabled: actif,
    queryFn: async () => {
      const { data, error } = await rpcLibre("admin_pressings", {});
      if (error) throw error;
      return (data ?? []) as PressingAdmin[];
    },
  });
}

export function useAdminPaiement() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (p: {
      pressingId: string;
      formule: CodeFormule;
      mois: number;
      montant: number;
      moyen: MoyenPaiement;
      reference: string;
    }) => {
      const { data, error } = await rpcLibre("admin_enregistrer_paiement", {
        p_pressing: p.pressingId,
        p_formule: p.formule,
        p_mois: p.mois,
        p_montant: p.montant,
        p_moyen: p.moyen,
        p_reference: p.reference.trim() || null,
      });
      if (error) throw error;
      return data as { debut: string; fin: string };
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["admin-pressings"] });
      void qc.invalidateQueries({ queryKey: ["abonnement"] });
    },
  });
}

export function useAdminSuspendre() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (p: { pressingId: string; suspendre: boolean }) => {
      const { error } = await rpcLibre("admin_suspendre", {
        p_pressing: p.pressingId,
        p_suspendre: p.suspendre,
      });
      if (error) throw error;
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["admin-pressings"] }),
  });
}
